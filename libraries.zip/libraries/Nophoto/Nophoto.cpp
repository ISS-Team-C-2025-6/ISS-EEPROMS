/**
 * ************************************************************
 * *******   QUEST S3 MICROLAB Nophoto data *******************
 * ************************************************************
 * 
 * Need to get the file name 
 * open a file with that name
 * place the Nophoto data into the file
 * make a header for nophoto with size 
 * 
 */